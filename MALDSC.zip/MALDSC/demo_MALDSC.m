clear;
addpath('tSVD','twist','data');
addpath('ClusteringMeasure', 'LRR',  'unlocbox');

% load orl.mat 
% fea= X';
% gnd = label;

load Yale.mat 
gnd = gnd';

% load extendyaleb.mat 
% fea= X';
% gnd = label;

% load usps_train_1k.mat 
% gnd = gnd';

% load ceu.mat 
% fea = X';
% gnd = C;

% load AR_glass.mat 
% gnd = gnd';


V=2; % the number of intrinsic attributes
K = ones(V,1)*50;

% p1 = [0.0001 0.001 0.01 0.1 1 10 100];
% % p1 = 0.1:0.1:2;
%   for lambda1 = p1
%       p2 = [0.0001 0.001 0.01 0.1 1 10 100];
% % p2 = 10:10:200;
%     for lambda2 = p2
%          p3 = [0.0001 0.001 0.01 0.1 1 10 100];
% % p3 = 10:10:200;
%              for lambda3 = p3
% %        p4 = [0.2 0.4 0.6 0.8 1 2];
%          p4 = [0.0001 0.001 0.01 0.1 0.5 1 1.5 2 5 10 122];
% % p4 = 1:0.2:10;
%                        for p = p4

% %-----------orl
% lambda1 = 0.001;
% lambda2 = 100;
% lambda3 = 1;
% p = 5;
%-------------yale
lambda1 = 0.01;
lambda2 = 1;
lambda3 = 10;
p = 0.1;
% %-------------Eyale B
% lambda1 = 0.1;
% lambda2 = 100;
% lambda3 = 10;
% p = 1;
% %-------------USPS
% lambda1 = 1;
% lambda2 = 100;
% lambda3 = 10;
% p = 10;
% %-------------CEU
% lambda1 = 0.001;
% lambda2 = 0.01;
% lambda3 = 0.001;
% p = 5;
% % -------------AR
% lambda1 = 0.0001;
% lambda2 = 0.1;
% lambda3 = 10;
% p = 2;


cls_num = length(unique(gnd));
% [Z]= MASC(fea,alpha,lambda,beta,p,V,K);
tic;
[Z]= MALDSC(fea,lambda1,lambda2,lambda3,p,V,K);
toc;
S = 0;
for v=1:V
    S = S + abs(Z{v})+abs(Z{v}');
end

pre_labels_C = SpectralClustering(S,cls_num);
result = Clustering8Measure(gnd, pre_labels_C);
fprintf('lambda1 %.4f lambda2 %.4f lambda3 %.4f  p  %.4f  ACC %.4f\n', lambda1,lambda2,lambda3,p,result(1));


%                    end
%             end
%        end
%  end




