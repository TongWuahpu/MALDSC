%%--------------------------------------------------------------------------
% Reference:
%
% Jipeng Guo, Yanfeng Sun, Junbin Gao, Yongli Hu, Baocai Yin: 
% Multi-attribute Subspace Clustering via Auto-weighted Tensor Nuclear Norm Minimization. 
% IEEE Transactions on Image Processing, DOI:10.1109/TIP.2022.3220949
%
%--------------------------------------------------------------------------
% Written by (guojipeng@emails.bjut.edu.cn)
%--------------------------------------------------------------------------




%% For convinience, we assume the order of the tensor is always 3;
% function [Z]= MASC(X,lambda1,lambda2,lambda3,p,V,K)
function [Z,data2]= MASC(X,lambda1,lambda2,lambda3,p,V,K)
% function [Z]= MASC(X,lambda,V,K)
% data feature X:d*n;
% parameters:lambda1,lambda2,lambda3;
% p: p-tensor nuclear norm. 0<p<=2 ;
% V: the number of multi-Attribute;
% K:V*1, K(v) is the reduced dimension for Attribute v, v = 1,2,...,V;

[~,n] = size(X);
X = NormalizeData(X);

%% Initialize Variables
for v=1:V
    H{v} = eye(K(v),n);
    Z{v} = zeros(n,n); % self-expressive matrix
    E{v} = zeros(K(v),n); % noise term
    Y{v} = zeros(K(v),n); % Lagrange multiplier
    M{v} = zeros(n,n);
    G{v} = zeros(n,n);
end
C = eye(K(1),K(1));
I = eye(K(1),K(1));
I_Z = eye(n,n);

m = zeros(n*n*V,1);
g = zeros(n*n*V,1);
sX = [n, n, V];

Isconverg = 0;
epson = 1e-7;
iter = 0;

mu = 10e-5; max_mu = 10e10; pho_mu = 2;
rho = 0.0001; max_rho = 10e12; pho_rho = 2;
while(Isconverg == 0)
%     fprintf('----processing iter %d--------\n', iter+1);
    
        % Update W{v}
        for v=1:V
        tmp1 = 2*X*H{v}'*C';
        tmp2 = 2*C*H{v}*H{v}'*C';
        W{v} = tmp1*pinv(tmp2);
        end   

        % Update C
        tmp3 = zeros(K(1),K(1));
        tmp4 = zeros(K(1),K(1));
        tmp5 = zeros(K(1),K(1));
        for v = 1:V
        tmp3 = tmp3 + W{v}'*W{v};
        tmp4 = tmp4 + W{v}'*X*H{v}';
        tmp5 = tmp5 + H{v}*H{v}';
        end
        C = pinv(2*tmp3)*2*tmp4*pinv(tmp5);

        % Update H{v}
        for v = 1:V
        tempA = 2*C'*W{v}'*W{v}*C + 2*lambda1*I + mu*I;
        tempB = -mu*Z{v} - mu*Z{v}' + mu*Z{v}*Z{v}';
        tempC = 2*C'*W{v}'*X - Y{v} + Y{v}*Z{v}' + mu*E{v} - mu*E{v}*Z{v}';
        H{v} = lyap(tempA,tempB,tempC);
        end
      
        % Update Z{v}
        for v = 1:V
        tmp6 = mu*H{v}'*H{v} + rho*I_Z;
        tmp7 = H{v}'*Y{v} + mu*H{v}'*H{v} - mu*H{v}'*E{v} - M{v} + rho*G{v};
        Z{v} = pinv(tmp6)*tmp7;       
        end

        % Update E{v}
        for v = 1:V
        tmp8 = Y{v} + mu*H{v} - mu*H{v}*Z{v};
        tmp9 = 2*lambda2*I_Z + mu*I_Z;
        E{v} = tmp8*pinv(tmp9);        
        end

        % Update Y{v}
        for v = 1:V
        Y{v} = Y{v} + mu*(H{v}-H{v}*Z{v}-E{v});
        end

     % update tensor G_tensor
     Z_tensor = cat(3, Z{:,:});
     M_tensor = cat(3, M{:,:});
     z = Z_tensor(:);
     w = M_tensor(:);
     if p==122
     [g, ~] = wshrinkObj(z + 1/rho*w,lambda3/rho,sX,0,3);
     else
         G_tensor = cat(3, G{:,:});
         [g] = Awshrink(G_tensor,z + 1/rho*w,lambda3/rho,p,sX,0,3);
     end
     G_tensor = reshape(g, sX);

     m = m + rho*(z - g);
     %% coverge condition
      Isconverg = 1;
      for v=1:V
          if (norm(H{v}-H{v}*Z{v}-E{v},inf)>epson)
            history.norm_Z = norm(H{v}-H{v}*Z{v}-E{v},inf);
             f = history.norm_Z;
%             fprintf('    norm_Z %7.10f    ', history.norm_Z);
             Isconverg = 0;
          end
          G{v} = G_tensor(:,:,v);
          M_tensor = reshape(m, sX);
          M{v} = M_tensor(:,:,v);
          if (norm(Z{v}-G{v},inf)>epson)
            history.norm_Z_G = norm(Z{v}-G{v},inf);
            b = history.norm_Z_G;
%             fprintf('norm_Z_G %7.10f    \n', history.norm_Z_G);
              Isconverg = 0;
          end

      end
      if (iter>100)
        Isconverg  = 1;
      end
      iter = iter + 1;
      mu = min(mu*pho_mu, max_mu);
      rho = min(rho*pho_rho, max_rho);
end
end
