function x =Awshrink(X_tensor,x,rho,p,sX,isWeight,mode,Iteration) 
% X_tensor : initialized tensor solution
if nargin<8 
    Iteration = 1;
end
if mode == 1
    Y=X2Yi(X_tensor,3);
elseif mode == 3
    Y=shiftdim(X_tensor, 1);
else
    Y = X_tensor;
end
for i =1:Iteration
    w = zeros(min(size(Y,1),size(Y,2)),1);
    Yhat = fft(Y,[],3);
    for j = 1:size(Yhat,3)
        [~,shat,~] = svd(full(Yhat(:,:,j)),'econ');
        for k = length(w)
            w(k) = w(k)+shat(k);
        end
    end

    weight = p*exp(-w.*p);

    [x,~] = WshrinkObj_weight(x,weight*rho,sX, isWeight,mode);
     X_tensor = reshape(x, sX);
    if mode == 1
       Y=X2Yi(X_tensor,3);
    elseif mode == 3
      Y=shiftdim(X_tensor, 1);
    else
      Y = X_tensor;
   end
end
end